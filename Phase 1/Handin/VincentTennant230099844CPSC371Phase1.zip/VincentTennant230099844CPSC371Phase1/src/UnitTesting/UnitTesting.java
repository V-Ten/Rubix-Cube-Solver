package UnitTesting;

/**
 * A series of unit tests for each class and object
 */
public class UnitTesting {
    
        public static void unitTest() {
        	//forgot :(
        }

    }













