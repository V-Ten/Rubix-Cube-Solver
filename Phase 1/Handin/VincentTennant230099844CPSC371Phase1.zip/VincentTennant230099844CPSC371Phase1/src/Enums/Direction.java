package Enums;

/**
 * Created by Vince on 1/28/2015.
 */
public enum Direction {
    CLOCKWISE, COUNTERCLOCKWISE;
}
