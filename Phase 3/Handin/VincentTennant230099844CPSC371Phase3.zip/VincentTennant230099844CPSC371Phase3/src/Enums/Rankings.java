package Enums;

/**
 * Created by Vince on 4/5/2015.
 */
public enum Rankings {
    FITNESS, DIVERSITY, COMBINED
}
